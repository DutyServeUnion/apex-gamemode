hi all vin here, this gamemode is awfully made so watch out.

i wont provide support for it, if you get any errors make sure the _mysql.lua file is configure correctly, and make sure you delete the 'gextention' module if you dont have gextention. 

other things will break loads, enjoy i guess. other addons may be needed that apex used, have a look at the collection we used.


credits:
datamats
vin
chessnut