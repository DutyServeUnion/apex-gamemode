


-- use chat.AddText() syntax
