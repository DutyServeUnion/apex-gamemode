ENT.Type = "anim"
ENT.Base = "base_anim"

ENT.PrintName		= "Theatre Console"
ENT.Author			= "TheVingard"
ENT.Contact			= ""
ENT.Purpose			= ""
ENT.Information		= ""
ENT.Category		= "HL2RP"

ENT.Spawnable = true
ENT.AdminOnly = true


