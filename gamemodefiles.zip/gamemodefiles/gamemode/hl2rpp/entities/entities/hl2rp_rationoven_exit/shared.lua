ENT.Type = "anim"
ENT.Base = "base_anim" 

ENT.PrintName		= "Ration Factory Oven Exit"
ENT.Author			= "Datamats"
ENT.Contact			= ""
ENT.Purpose			= "Make that ration."
ENT.Information		= "Make that ration."
ENT.Category		= "HL2RP"

ENT.Spawnable = false
ENT.AdminOnly = false