ENT.Type = "anim"
ENT.Base = "base_anim" 

ENT.PrintName		= "Raw ration"
ENT.Author			= "Datamats"
ENT.Contact			= ""
ENT.Purpose			= "Make that ration."
ENT.Information		= "Make that ration."
ENT.Category		= "HL2RP"

ENT.Spawnable = false
ENT.AdminOnly = false