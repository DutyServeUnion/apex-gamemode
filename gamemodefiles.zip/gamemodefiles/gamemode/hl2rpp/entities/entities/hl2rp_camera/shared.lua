ENT.Type = "anim"
ENT.Base = "base_anim" 

ENT.PrintName		= "CCTV Camera"
ENT.Author			= "Datamats"
ENT.Contact			= ""
ENT.Purpose			= "NSA"
ENT.Information		= "NSA"
ENT.Category		= "HL2RP"

ENT.Spawnable = false
ENT.AdminOnly = false