ENT.Type = "anim"
ENT.Base = "base_gmodentity"
ENT.PrintName		= "Larval Extract"
ENT.Author			= "TheVingard"
ENT.Contact			= "N/A"
ENT.Purpose			= "Change outfit"
ENT.Instructions	= "Press E"
ENT.Category 		= "Roleplay"

ENT.Spawnable = true
ENT.AdminOnly = true



