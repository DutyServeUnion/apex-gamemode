ENT.Type = "anim"
ENT.Base = "base_anim" 

ENT.PrintName		= "CWU Ration"
ENT.Author			= "Vin :3"
ENT.Contact			= ""
ENT.Purpose			= "Make that ration."
ENT.Information		= "Make that ration."
ENT.Category		= "HL2RP"

ENT.Spawnable			= false
ENT.AdminSpawnable		= true