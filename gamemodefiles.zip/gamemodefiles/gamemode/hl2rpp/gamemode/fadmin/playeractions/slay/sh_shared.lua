FAdmin.PlayerActions.SlayTypes = {}
FAdmin.PlayerActions.SlayTypes[1] = "Normal"
FAdmin.PlayerActions.SlayTypes[2] = "Silent"
FAdmin.PlayerActions.SlayTypes[3] = "Explode"
FAdmin.PlayerActions.SlayTypes[4] = "Rocket"