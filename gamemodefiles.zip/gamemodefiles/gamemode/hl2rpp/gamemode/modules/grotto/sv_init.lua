--print("Grotto-init")


/*
function checkGrottoPiano()
	no = true
	for k, v in pairs(ents.FindByClass("gmt_instrument_piano")) do
		--no = false
		v:Remove()
		--print("Yup")
	end
	if no then
		local ent = ents.Create( "gmt_instrument_piano" )
		local pos = Vector(5530.006836, 5433.938965+20, 400.031250-65)
		local ang = Angle(0, 0, 0)
		ent:SetPos( pos )
		ent:SetAngles( ang )
		ent:Spawn()
		ent:Activate()
		ent:SetMoveType(MOVETYPE_NONE)

	end
end

timer.Simple( 2, function()
	checkGrottoPiano()
end )

*/